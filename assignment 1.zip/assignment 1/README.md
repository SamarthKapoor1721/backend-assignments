Task: Log Request Information to a File Using fs Module in Express.js
Objective: Create an Express.js application that logs essential request information (timestamp,
IP, URL, protocol, HTTP method, and hostname) to a file using the fs (File System) module.
This task will help you understand middleware in Express.js and how to interact with the file
system in Node.js.
